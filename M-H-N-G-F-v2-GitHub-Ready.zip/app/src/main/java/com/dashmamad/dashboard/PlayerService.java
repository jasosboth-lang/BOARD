package com.dashmamad.dashboard;
import android.app.*;import android.content.*;import android.media.*;import android.os.*;import java.io.*;
public class PlayerService extends Service{
 public static final String PLAY="PLAY", PAUSE="PAUSE", STOP="STOP"; MediaPlayer mp;
 @Override public int onStartCommand(Intent i,int f,int id){
  if(i!=null){
   if(PLAY.equals(i.getAction())){String p=i.getStringExtra("path");play(p);}
   else if(PAUSE.equals(i.getAction())&&mp!=null){if(mp.isPlaying())mp.pause();else mp.start();}
   else if(STOP.equals(i.getAction())){stopSelf();}
  }
  return START_STICKY;
}
 void play(String p){try{if(mp!=null){mp.stop();mp.release();}mp=new MediaPlayer();mp.setDataSource(p);mp.setAudioStreamType(AudioManager.STREAM_MUSIC);mp.setOnPreparedListener(x->{x.start();startFG();});mp.setOnCompletionListener(x->{});mp.prepareAsync();}catch(Exception e){stopSelf();}}
 void startFG(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("music","Music",NotificationManager.IMPORTANCE_LOW));Intent pi=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,pi,PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"music"):new Notification.Builder(this);b.setContentTitle("DashMamad Music").setContentText("Music is playing").setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(p);startForeground(7,b.build());}
 @Override public void onDestroy(){if(mp!=null){mp.stop();mp.release();mp=null;}super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
