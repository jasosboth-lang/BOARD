package com.dashmamad.dashboard;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int REQ_AUDIO=10, REQ_BG=11;
    FrameLayout root; ImageView bg; LinearLayout content, nav;
    SharedPreferences sp;
    int gold=Color.rgb(222,176,76);
    boolean dark=true;
    ArrayList<String> workoutTitles=new ArrayList<>();
    ArrayList<String> workoutNotes=new ArrayList<>();

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); b.setTextColor(dark?Color.WHITE:Color.DKGRAY); b.setPadding(dp(8),0,dp(8),0); GradientDrawable g=new GradientDrawable(); g.setColor(dark?0xBB171717:0xE6FFFFFF); g.setCornerRadius(dp(16)); g.setStroke(dp(1),0x55DDB04C); b.setBackground(g); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(Color.BLACK);
        sp=getSharedPreferences("dash",0); dark=sp.getBoolean("dark",true);
        loadWorkouts(); showHome();
    }
    ImageButton navIcon(int drawable, String description){
        ImageButton b=new ImageButton(this);
        b.setImageResource(drawable);
        b.setContentDescription(description);
        b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        b.setPadding(dp(12),dp(10),dp(12),dp(10));
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setColorFilter(null);
        return b;
    }

    void base(){
        root=new FrameLayout(this);
        bg=new ImageView(this); bg.setImageResource(com.dashmamad.dashboard.R.drawable.home_background); bg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        // The original background is already black. In dark mode it must stay untouched.
        View shade=new View(this); shade.setBackgroundColor(dark?Color.TRANSPARENT:0x22000000); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18),dp(18),dp(18),dp(8));
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-1); cp.bottomMargin=dp(76); root.addView(content,cp);

        nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(10),dp(5),dp(10),dp(5));
        nav.setBackgroundColor(dark?Color.BLACK:Color.WHITE);
        int[] icons={R.drawable.ic_music,R.drawable.ic_book,R.drawable.ic_workout,R.drawable.ic_theme};
        String[] descriptions={"Music","Book","Workout","Change theme"};
        for(int i=0;i<4;i++){
            final int k=i;
            ImageButton x=navIcon(icons[i],descriptions[i]);
            x.setOnClickListener(v->{if(k==0)showMusic();else if(k==1)showBook();else if(k==2)showWorkout();else toggleTheme();});
            nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));
        }
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(70),Gravity.BOTTOM); np.setMargins(dp(12),0,dp(12),dp(10)); root.addView(nav,np);
        setContentView(root);
    }

    void showHome(){
        base(); content.removeAllViews();
        // Clock/date sit higher on the screen than v1, with a deliberate English typeface.
        Space top=new Space(this); content.addView(top,new LinearLayout.LayoutParams(1,dp(54)));
        TextView clock=tv("",44,gold); clock.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); clock.setGravity(Gravity.CENTER);
        clock.setLetterSpacing(0.05f); clock.setShadowLayer(dp(7),0,dp(3),0xAA000000);
        content.addView(clock,new LinearLayout.LayoutParams(-1,dp(78)));
        TextView date=tv("",15,Color.WHITE); date.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); date.setGravity(Gravity.CENTER);
        date.setLetterSpacing(0.04f); date.setShadowLayer(4,0,2,Color.BLACK); content.addView(date,new LinearLayout.LayoutParams(-1,dp(34)));
        Space bottom=new Space(this); content.addView(bottom,new LinearLayout.LayoutParams(1,0,1));
        Runnable tick=new Runnable(){ public void run(){ Date d=new Date(); Locale english=Locale.US; clock.setText(new SimpleDateFormat("HH:mm:ss",english).format(d)); date.setText(new SimpleDateFormat("EEEE  •  dd MMMM yyyy",english).format(d)); clock.postDelayed(this,1000);}};
        clock.post(tick);
    }
    TextView title(String s){ TextView t=tv(s,26,dark?Color.WHITE:Color.DKGRAY); t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0,dp(8),0,dp(10)); return t; }
    void clearPage(String s){ base(); content.removeAllViews(); LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView h=title(s); top.addView(h,new LinearLayout.LayoutParams(0,dp(58),1)); Button home=btn("⌂"); home.setOnClickListener(v->showHome()); top.addView(home,new LinearLayout.LayoutParams(dp(50),dp(44))); content.addView(top); }
    void showMusic(){
        clearPage("Music");
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
        Button scan=btn("↻ Refresh"); Button pause=btn("Ⅱ / ▶"); Button stop=btn("■ Stop");
        controls.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));
        controls.addView(pause,new LinearLayout.LayoutParams(dp(80),dp(44)));
        controls.addView(stop,new LinearLayout.LayoutParams(dp(80),dp(44)));
        content.addView(controls);
        pause.setOnClickListener(v->{Intent i=new Intent(this,PlayerService.class);i.setAction(PlayerService.PAUSE);startService(i);});
        stop.setOnClickListener(v->{Intent i=new Intent(this,PlayerService.class);i.setAction(PlayerService.STOP);startService(i);});
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this); sv.addView(list); content.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        scan.setOnClickListener(v->loadSongs(list));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO},REQ_AUDIO);
        else if(Build.VERSION.SDK_INT<33 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQ_AUDIO);
        else loadSongs(list);
    }
    void loadSongs(LinearLayout list){
        list.removeAllViews(); Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.DATA},MediaStore.Audio.Media.IS_MUSIC+"!=0",null,MediaStore.Audio.Media.TITLE+" ASC");
        if(c!=null){while(c.moveToNext()){String name=c.getString(1), path=c.getString(2); Button b=btn("▶  "+name); b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setOnClickListener(v->startMusic(path)); list.addView(b,new LinearLayout.LayoutParams(-1,dp(48)));}c.close();}
        if(list.getChildCount()==0) list.addView(tv("No local music found.",16,Color.WHITE));
    }
    void startMusic(String path){ Intent i=new Intent(this,PlayerService.class); i.setAction(PlayerService.PLAY); i.putExtra("path",path); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); Toast.makeText(this,"Playing in background",Toast.LENGTH_SHORT).show(); }
    void showBook(){
        clearPage("📕  Book");
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); Button settings=btn("⚙ Customize"); bar.addView(settings,new LinearLayout.LayoutParams(0,dp(44),1)); Button save=btn("Save & Quit"); bar.addView(save,new LinearLayout.LayoutParams(dp(120),dp(44))); content.addView(bar);
        EditText ed=new EditText(this); ed.setGravity(Gravity.TOP|Gravity.LEFT); ed.setText(sp.getString("book","")); ed.setTextSize(sp.getFloat("font",18));
        String bookBg=sp.getString("bookbg","");
        if(!bookBg.isEmpty()) try { android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(bookBg))); if(bm!=null){ android.graphics.drawable.BitmapDrawable bd=new android.graphics.drawable.BitmapDrawable(getResources(),bm); bd.setAlpha(115); ed.setBackground(bd); } } catch(Exception ignored) {} ed.setTextColor(Color.WHITE); ed.setHint("Start writing..."); ed.setHintTextColor(0xAAFFFFFF); ed.setPadding(dp(16),dp(16),dp(16),dp(16)); ed.setBackground(round(0x77000000,20)); content.addView(ed,new LinearLayout.LayoutParams(-1,0,1));
        settings.setOnClickListener(v->bookSettings(ed)); save.setOnClickListener(v->{sp.edit().putString("book",ed.getText().toString()).apply();showHome();});
        ed.setOnFocusChangeListener((v,f)->{if(!f)sp.edit().putString("book",ed.getText().toString()).apply();});
    }
    GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    void bookSettings(EditText ed){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),dp(10),dp(20),dp(10));
        SeekBar size=new SeekBar(this); size.setMax(32); size.setProgress((int)sp.getFloat("font",18)-10); box.addView(tv("Font size",16,dark?Color.WHITE:Color.DKGRAY)); box.addView(size);
        Button bgpick=btn("Choose Book Background"); box.addView(bgpick,new LinearLayout.LayoutParams(-1,dp(44)));
        Button color=btn("Text color: "+(sp.getBoolean("yellow",false)?"Gold":"White")); box.addView(color,new LinearLayout.LayoutParams(-1,dp(44)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Book customization").setView(box).setPositiveButton("Done",(x,w)->{}).create(); 
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){ed.setTextSize(10+p);sp.edit().putFloat("font",10+p).apply();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        color.setOnClickListener(v->{boolean y=!sp.getBoolean("yellow",false);sp.edit().putBoolean("yellow",y).apply();ed.setTextColor(y?gold:Color.WHITE);color.setText("Text color: "+(y?"Gold":"White"));});
        bgpick.setOnClickListener(v->{d.dismiss();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_BG);});
        d.setOnShowListener(x->{ed.setTextColor(sp.getBoolean("yellow",false)?gold:Color.WHITE);}); d.show();
    }
    void showWorkout(){
        clearPage("🏋  Workout");
        TextView info=tv("10 training slots  •  Tap a slot to view / create",13,dark?0xCCFFFFFF:0xCC333333); content.addView(info,new LinearLayout.LayoutParams(-1,dp(35)));
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); content.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        for(int i=0;i<10;i++){final int k=i;String name=workoutTitles.get(i);Button b=btn((name.isEmpty()?"＋  Empty slot "+(i+1):"◆  "+name));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->workoutDetail(k));list.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));Space spc=new Space(this);list.addView(spc,new LinearLayout.LayoutParams(1,dp(7)));}
    }
    void workoutDetail(int k){
        String current=workoutTitles.get(k); if(current.isEmpty()){final EditText input=new EditText(this);input.setHint("Exercise title"); new AlertDialog.Builder(this).setTitle("Enter your title").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Confirm",(d,w)->{workoutTitles.set(k,input.getText().toString().trim());saveWorkouts();workoutDetail(k);}).show();return;}
        clearPage(current);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);Button edit=btn("✎ Edit");Button save=btn("Save & Quit");bar.addView(edit,new LinearLayout.LayoutParams(0,44*dp(1),1));bar.addView(save,new LinearLayout.LayoutParams(dp(120),dp(44)));content.addView(bar);
        EditText ed=new EditText(this);ed.setText(workoutNotes.get(k));ed.setTextColor(dark?Color.WHITE:Color.DKGRAY);ed.setTextSize(17);ed.setGravity(Gravity.TOP|Gravity.LEFT);ed.setPadding(dp(16),dp(16),dp(16),dp(16));ed.setBackground(round(dark?0x66000000:0xCCFFFFFF,20));ed.setFocusable(false);ed.setCursorVisible(false);content.addView(ed,new LinearLayout.LayoutParams(-1,0,1));
        edit.setOnClickListener(v->{ed.setFocusableInTouchMode(true);ed.setFocusable(true);ed.setCursorVisible(true);ed.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(ed,InputMethodManager.SHOW_IMPLICIT);});
        save.setOnClickListener(v->{workoutNotes.set(k,ed.getText().toString());saveWorkouts();showWorkout();});
    }
    void loadWorkouts(){for(int i=0;i<10;i++){workoutTitles.add(sp.getString("wt"+i,""));workoutNotes.add(sp.getString("wn"+i,""));}}
    void saveWorkouts(){SharedPreferences.Editor e=sp.edit();for(int i=0;i<10;i++){e.putString("wt"+i,workoutTitles.get(i));e.putString("wn"+i,workoutNotes.get(i));}e.apply();}
    void toggleTheme(){dark=!dark;sp.edit().putBoolean("dark",dark).apply();showHome();}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_BG&&c==RESULT_OK&&d!=null){try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);sp.edit().putString("bookbg",d.getData().toString()).apply();}catch(Exception e){}}}
    @Override public void onBackPressed(){showHome();}
}
