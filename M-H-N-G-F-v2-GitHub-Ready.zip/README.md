# M.H.N.G.F — Android Dashboard v2

This is the GitHub-ready Android Studio project for version 2.

## v2 changes
- App name: `M.H.N.G.F`
- New launcher icon included.
- Original cat-with-red-rose background retained.
- Clock and date moved higher on the home screen.
- Clock/date use English formatting (`Locale.US`).
- Bottom navigation uses custom vector icons instead of emoji/stickers.
- Dark mode does **not** darken the already-black background; only the bottom navigation bar becomes black.
- Existing Music, Book/Notes, Workout and theme functionality remains.

## Build
The repository includes `.github/workflows/build-apk.yml`. After pushing this project to a GitHub repository, the workflow can be run from **Actions → Build Android APK → Run workflow**. It installs the required Android SDK and Gradle versions, builds the debug APK, and uploads it as the `M-H-N-G-F-debug-apk` artifact.
